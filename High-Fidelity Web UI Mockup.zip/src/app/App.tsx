import { useState, useRef } from "react";
import {
  Search,
  Flame,
  Anchor,
  TrendingDown,
  TrendingUp,
  TrendingUpDown,
  Lock,
  GripVertical,
  Image as ImageIcon,
  ChevronDown,
  Layers,
  Plus,
  Minus,
  Calculator,
  X,
  TriangleAlert,
  Share2,
  Check,
  RotateCcw,
  Activity,
  ArrowDown,
  Crown,
  Zap,
  Coins,
} from "lucide-react";

// ─── Types ───────────────────────────────────────────────────────────────────

type UnitStatus =
  | "stable" | "unstable" | "rising" | "dropping"
  | "inflated" | "deflated" | "varies" | "maximum"
  | "hyped" | "gatekept" | "black-marketed";
type FilterKey = "All" | "S" | "A" | "B" | "C";

interface MasterUnit {
  id: string;
  name: string;
  subtitle: string;
  value: number | "owner" | "range";
  valueDisplay?: string;
  valueMin?: number;        // for sorting range units
  rarity: number;
  supply: number;
  demand: number;
  status?: UnitStatus;
  isNew?: boolean;
  notice?: string;
  imageUrl?: string;
}

// Compute tier from numeric value
function getTier(v: MasterUnit["value"]): "S" | "A" | "B" | "C" {
  if (v === "owner" || v === "range") return "S";
  if (v >= 10000) return "S";
  if (v >= 300) return "A";
  if (v >= 100) return "B";
  return "C";
}

// Sort-safe numeric representation
function sortVal(u: MasterUnit): number {
  if (u.value === "owner") return 2_000_000_000;
  if (u.value === "range") return u.valueMin ?? 400_000;
  return u.value;
}

// Legacy alias so other components still compile
type Unit = MasterUnit;
type GridUnit = MasterUnit;

// ─── Image URLs (keyed by unit id) ───────────────────────────────────────────

const UNIT_IMAGES: Record<string, string> = {
  "death":        "https://static.wikia.nocookie.net/allstartd/images/5/59/Death_%28Pose%29.png/revision/latest?cb=20230909020936",
  "beardcutter":  "https://static.wikia.nocookie.net/allstartd/images/7/7d/Beardcutter_%28Pose%29.png/revision/latest?cb=20240301052022",
  "galaxy-girl":  "https://static.wikia.nocookie.net/allstartd/images/b/bd/Galaxy_Girl_%28Pose%29.png/revision/latest?cb=20240710101742",
  "demise":       "https://static.wikia.nocookie.net/allstartd/images/8/82/Demise.png/revision/latest?cb=20240815230519",
  "ultra-kovegu": "https://static.wikia.nocookie.net/allstartd/images/6/69/Ultra_Kovegu_%28Pose%29.png/revision/latest?cb=20260810231508",
};

// ─── Master unit list (single source of truth) ───────────────────────────────

const ALL_UNITS: MasterUnit[] = [
  // ── Top S Tier (100,000+) ──
  {
    id: "demise",
    name: "Demise",
    subtitle: "Rem Shinigami",
    value: "owner",
    rarity: 20, supply: 1, demand: 1,
    status: "black-marketed",
    imageUrl: UNIT_IMAGES["demise"],
    notice: "Obtainable from winning the VOTW (Video of the Week) contest. 3 Copies exist.",
  },
  {
    id: "galaxy-girl",
    name: "Galaxy Girl",
    subtitle: "Sasaki Miyo",
    value: "range", valueDisplay: "400,000 - ???", valueMin: 400_000,
    rarity: 20, supply: 4, demand: 1,
    status: "maximum",
    imageUrl: UNIT_IMAGES["galaxy-girl"],
    notice: "Female Gojo reskin, GAME contributor unit.",
  },
  {
    id: "beardcutter",
    name: "Beardcutter",
    subtitle: "Goblin Slayer",
    value: 210000,
    rarity: 19.5, supply: 3, demand: 1,
    status: "maximum",
    imageUrl: UNIT_IMAGES["beardcutter"],
    notice: "Given out during Pucci update for Wiki workers and contributors.",
  },
  {
    id: "ul-borul-alt",
    name: "Ultra Legendary Borul (Alt)",
    subtitle: "Ultra DBZ Broly",
    value: 160000,
    rarity: 20, supply: 1, demand: 1,
    status: "gatekept",
    notice: "Obtained by evolving 3 DBZ Broly. Pretty gatekept.",
  },
  {
    id: "death",
    name: "Death",
    subtitle: "Ryuk",
    value: 160000,
    rarity: 19, supply: 3, demand: 3,
    status: "varies",
    imageUrl: UNIT_IMAGES["death"],
    notice: "Obtainable from winning the VOTW (Video of the Week) contest.",
  },
  {
    id: "two-hands",
    name: "Two Hands",
    subtitle: "Revy",
    value: 110000,
    rarity: 19.5, supply: 3, demand: 3,
    status: "gatekept",
    notice: "Obtainable by being level 150 in the main server. Not given out as of now.",
  },
  {
    id: "l-borul-alt",
    name: "Legendary Borul (Alt)",
    subtitle: "DBZ Broly",
    value: 110000,
    rarity: 19.5, supply: 3, demand: 3,
    status: "stable",
    notice: "Originally given to Wiki / Trello Staff members.",
  },

  // ── Mid S Tier (20,000 – 99,999) ──
  {
    id: "slayer-mage",
    name: "Slayer Mage",
    subtitle: "Frieren",
    value: 40000,
    rarity: 13.5, supply: 4, demand: 2.5,
    status: "dropping",
    notice: "(700 Copies) — Was obtained from the Limited Shop for 3,000 Robux.",
  },
  {
    id: "bunny-girl",
    name: "Bunny Girl",
    subtitle: "Mai Sakurajima",
    value: 35000,
    rarity: 15, supply: 2.5, demand: 2,
    status: "stable",
    notice: "(<= 500 Copies) — Obtainable from the Exotic Coin. Got her old model back.",
  },
  {
    id: "frost-moon",
    name: "Frost Moon",
    subtitle: "Douma",
    value: 30000,
    rarity: 15, supply: 2.5, demand: 3,
    status: "stable",
    notice: "(>= 500 Copies) — Obtainable from the Exotic Coin.",
  },
  {
    id: "gold-dark-wing",
    name: "Gold Dark Wing",
    subtitle: "Gold Ulquiorra",
    value: 26000,
    rarity: 17, supply: 3, demand: 2.5,
    status: "stable",
    notice: "Obtained from evolving 5 Ulquiorra.",
  },
  {
    id: "club-beast",
    name: "Club Beast",
    subtitle: "Kaido",
    value: 23000,
    rarity: 16, supply: 3, demand: 3,
    status: "stable",
    notice: "First ever leaderboard unit, now retired. Got his old model back. One of the most stable S tiers.",
  },
  {
    id: "old-will",
    name: "Old Will",
    subtitle: "Yamamoto",
    value: 22000,
    rarity: 16, supply: 3, demand: 3,
    status: "stable",
    notice: "Retired Double Path leaderboard unit. One of the most stable S tiers.",
  },
  {
    id: "first-wood-bender",
    name: "First Wood Bender",
    subtitle: "Hashirama",
    value: 20000,
    rarity: 16, supply: 3, demand: 2.5,
    status: "stable",
    notice: "Retired Normal infinite leaderboard unit. One of the most stable S tiers.",
  },
  {
    id: "light-rock-blaster",
    name: "Light Rock Blaster",
    subtitle: "Shiny Stella",
    value: 20000,
    rarity: 15, supply: 3, demand: 3.5,
    status: "stable",
    notice: "Obtainable from Angelic Capsules. Shiny Version of a Legendary Rarity drop.",
  },
  {
    id: "ultra-kovegu",
    name: "Ultra Kovegu",
    subtitle: "SSJ3 Gogeta",
    value: 20000,
    rarity: 19, supply: 3, demand: 4,
    status: "inflated",
    imageUrl: UNIT_IMAGES["ultra-kovegu"],
    notice: "Obtainable from evolving 10 Gogeta's (Gets overpays, usually beyond the price of 10 Gogetas).",
  },

  // ── Low S Tier (10,000 – 19,999) ──
  {
    id: "gold-flame-servant",
    name: "Gold Flame Servant",
    subtitle: "Gold Senji Muramasa",
    value: 18500,
    rarity: 17, supply: 4, demand: 2,
    status: "dropping",
    notice: "Obtainable from evolving 3 Senji Muramasa. Owners panic trading for no reason.",
  },
  {
    id: "kageni",
    name: "Kageni",
    subtitle: "Cid Kagenou",
    value: 17000,
    rarity: 8, supply: 3, demand: 3.5,
    status: "black-marketed",
    notice: "Obtainable from the 100% Egg - Dark. Loved by BMers.",
  },
  {
    id: "illusiva",
    name: "Illusiva",
    subtitle: "Nero Padoru",
    value: 16000,
    rarity: 13, supply: 2.5, demand: 4,
    status: "gatekept",
    notice: "(~1000 Copies) Obtainable from the Exotic Coin. (Unobtainable)",
  },
  {
    id: "gold-jinjou",
    name: "Gold Jinjou",
    subtitle: "Gold Cumber",
    value: 16000,
    rarity: 17, supply: 4, demand: 2,
    status: "stable",
    notice: "Obtainable from evolving 5 Cumber.",
  },
  {
    id: "ikki-anni",
    name: "Ikki (Anni)",
    subtitle: "Anniversary Ichigo",
    value: 15000,
    rarity: 11, supply: 3, demand: 3.5,
    status: "stable",
    notice: "Obtainable from the Easter Capsule(+). Rarity Legendary. (Unobtainable)",
  },
  {
    id: "gold-tomi",
    name: "Gold Tomi",
    subtitle: "Gold Tobi",
    value: 15000,
    rarity: 17, supply: 4, demand: 2,
    status: "stable",
    notice: "Obtainable from evolving 5 Tobi.",
  },
  {
    id: "gold-martial-artist",
    name: "Gold Martial Artist",
    subtitle: "Gold Jin Mori",
    value: 13000,
    rarity: 17, supply: 3, demand: 3.5,
    status: "stable",
    notice: "Obtainable from evolving 5 Jin Mori.",
  },
  {
    id: "challenger-flaming-tiger",
    name: "Challenger Flaming Tiger",
    subtitle: "Challenger Rengoku",
    value: 10500,
    rarity: 14, supply: 3, demand: 3.5,
    status: "rising",
    notice: "Part of the 'PvP Set 1.0'. Finally got his blessing after 6 years.",
  },
  {
    id: "dark-rock-blaster",
    name: "Dark Rock Blaster",
    subtitle: "Stella",
    value: 10000,
    rarity: 14, supply: 3, demand: 2.5,
    status: "stable",
    notice: "Obtainable from Angelic Capsules. Legendary Rarity.",
  },

  // ── A Tier (300 – 9,999) ──
  {
    id: "leaf",
    name: "Leaf",
    subtitle: "Koishi Komeji",
    value: 8500,
    rarity: 13.5, supply: 3, demand: 4,
    status: "varies",
    notice: "(800 Copies) Varies Absurdly. Obtainable from the Limited Shop for 3,000 Robux. (Regional prices applied for some)",
  },
  {
    id: "spirit-knight",
    name: "Spirit Knight",
    subtitle: "Julius Juukulius",
    value: 5000,
    rarity: 13.5, supply: 3, demand: 3.5,
    status: "stable",
    notice: "(800 Copies) Obtainable from the Limited Shop for 1,000 Robux. (Regional prices applied for some)",
  },
];

// Derived arrays used by TIER_CONFIG and roster
const S_UNITS = ALL_UNITS.filter(u => getTier(u.value) === "S");
const A_UNITS = ALL_UNITS.filter(u => getTier(u.value) === "A");
const B_UNITS = ALL_UNITS.filter(u => getTier(u.value) === "B");
const C_UNITS = ALL_UNITS.filter(u => getTier(u.value) === "C");

const ROSTER = ALL_UNITS; // alias for sidebar

const FILTERS: FilterKey[] = ["All", "S", "A", "B", "C"];

// ─── Status icon ─────────────────────────────────────────────────────────────

function StatusIcon({ status, size = 11 }: { status: UnitStatus; size?: number }) {
  const s = { width: size, height: size };
  const b = "flex-shrink-0";
  if (status === "stable")        return <Anchor         style={s} className={`${b} text-sky-400`} />;
  if (status === "unstable")      return <Activity       style={s} className={`${b} text-yellow-400`} />;
  if (status === "rising")        return <TrendingUp     style={s} className={`${b} text-emerald-400`} />;
  if (status === "dropping")      return <TrendingDown   style={s} className={`${b} text-zinc-500`} />;
  if (status === "inflated")      return <Flame          style={s} className={`${b} text-orange-400`} />;
  if (status === "deflated")      return <ArrowDown      style={s} className={`${b} text-blue-400`} />;
  if (status === "varies")        return <TrendingUpDown style={s} className={`${b} text-amber-400`} />;
  if (status === "maximum")       return <Crown          style={s} className={`${b} text-yellow-300`} />;
  if (status === "hyped")         return <Zap            style={s} className={`${b} text-pink-400`} />;
  if (status === "gatekept")      return <Lock           style={s} className={`${b} text-violet-400`} />;
  if (status === "black-marketed") return <Coins         style={s} className={`${b} text-rose-400`} />;
  return null;
}

// ─── Tier badge ───────────────────────────────────────────────────────────────

const TIER_STYLES: Record<string, string> = {
  S:    "text-yellow-300  bg-yellow-400/10  border-yellow-400/20",
  A:    "text-orange-300  bg-orange-400/10  border-orange-400/20",
  B:    "text-blue-300    bg-blue-400/10    border-blue-400/20",
  C:    "text-zinc-400    bg-zinc-500/10    border-zinc-500/20",
  Pure: "text-purple-300  bg-purple-400/10  border-purple-400/20",
};

function TierBadge({ tier }: { tier: string }) {
  return (
    <span
      className={`inline-block text-[9px] font-mono font-black px-1.5 py-[1px] rounded border ${TIER_STYLES[tier] ?? "text-zinc-500 bg-zinc-600/10 border-zinc-600/20"}`}
    >
      {tier}
    </span>
  );
}

// ─── Value display ────────────────────────────────────────────────────────────

function ValueDisplay({ unit }: { unit: Unit }) {
  if (unit.value === "owner") {
    return (
      <span
        className="text-sm font-black"
        style={{
          background: "linear-gradient(90deg, #a78bfa, #f472b6)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          backgroundClip: "text",
          fontFamily: "'Inter', sans-serif",
        }}
      >
        O/C
      </span>
    );
  }
  if (unit.value === "range") {
    return (
      <span
        className="text-sm font-bold"
        style={{ color: "#9ea3ad", fontFamily: "'JetBrains Mono', monospace" }}
      >
        {unit.valueDisplay ?? "???"}
      </span>
    );
  }
  return (
    <span
      className="text-sm font-bold text-zinc-200"
      style={{ fontFamily: "'JetBrains Mono', monospace" }}
    >
      {(unit.value as number).toLocaleString()}
    </span>
  );
}

// ─── Stat chip row ────────────────────────────────────────────────────────────

function StatRow({ unit }: { unit: Unit }) {
  const fmt = (v: number) => (v % 1 === 0 ? String(v) : v.toFixed(1));
  const stats = [
    { label: "R", value: unit.rarity },
    { label: "S", value: unit.supply },
    { label: "D", value: unit.demand },
  ];
  return (
    <div className="flex items-center gap-3">
      {stats.map(({ label, value }) => (
        <div key={label} className="flex items-center gap-[4px]">
          <span
            className="text-[14px] font-black uppercase leading-none"
            style={{ color: "#8c9099", fontFamily: "'JetBrains Mono', monospace" }}
          >
            {label}
          </span>
          <span
            className="text-[14px] font-black leading-none"
            style={{ color: "#e3e5e8", fontFamily: "'JetBrains Mono', monospace" }}
          >
            {fmt(value)}
          </span>
        </div>
      ))}
    </div>
  );
}

// ─── Unit card ────────────────────────────────────────────────────────────────

function UnitCard({ unit, onAddClick }: { unit: Unit; onAddClick?: (u: PopupUnit, e: React.MouseEvent) => void }) {
  const popupUnit: PopupUnit = {
    id: unit.id,
    name: unit.name,
    subtitle: unit.subtitle,
    value: typeof unit.value === "number" ? unit.value : 0,
    demand: unit.demand,
  };

  const handleDragStart = (e: React.DragEvent) => {
    e.dataTransfer.setData("unit", JSON.stringify(popupUnit));
    e.dataTransfer.effectAllowed = "copy";
  };

  return (
    <div
      draggable
      onDragStart={handleDragStart}
      className="group flex items-center gap-3 px-3 py-4 rounded-xl cursor-grab active:cursor-grabbing transition-colors relative"
      style={{ userSelect: "none" }}
      onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(78,80,88,0.3)")}
      onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
    >
      {/* Square image placeholder */}
      <div
        className="squircle flex-shrink-0 flex items-center justify-center relative overflow-hidden"
        style={{
          width: 54,
          height: 54,
          background: "linear-gradient(145deg, #383a3f, #27292d)",
          border: "1px solid rgba(255,255,255,0.07)",
        }}
      >
        {unit.imageUrl ? (
          <img
            src={unit.imageUrl}
            alt={unit.name}
            className="absolute inset-0 w-full h-full"
            style={{ objectFit: "cover", objectPosition: "center 15%" }}
            onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = "none"; }}
          />
        ) : (
          <ImageIcon style={{ width: 18, height: 18 }} className="text-zinc-700" />
        )}
        {/* Tier flash in corner */}
        <div className="absolute bottom-1 right-1">
          <TierBadge tier={getTier(unit.value)} />
        </div>
      </div>

      {/* Card content */}
      <div className="flex-1 min-w-0">
        {/* Name row */}
        <div className="flex items-center gap-1.5 mb-[2px]">
          <span
            className="text-[14px] font-bold leading-none truncate"
            style={{ color: "#ffffff", fontFamily: "'Inter', sans-serif" }}
          >
            {unit.name}
          </span>
          {unit.status && <StatusIcon status={unit.status} size={11} />}
          {unit.notice && <NoticeTooltip notice={unit.notice} />}
          {unit.isNew && (
            <span
              className="text-[8px] font-black px-1.5 py-[1px] rounded-full flex-shrink-0 tracking-wider"
              style={{
                background: "rgba(87,242,135,0.12)",
                color: "#57f287",
                border: "1px solid rgba(87,242,135,0.25)",
                lineHeight: "1.4",
              }}
            >
              NEW
            </span>
          )}
        </div>

        {/* Subtitle */}
        <div
          className="text-[12px] truncate mb-2 leading-none"
          style={{ color: "#9ea3ad", fontFamily: "'Inter', sans-serif" }}
        >
          {unit.subtitle}
        </div>

        {/* Value + stats row */}
        <div className="flex items-center gap-3">
          <ValueDisplay unit={unit} />
          <div
            className="w-px self-stretch"
            style={{ background: "rgba(255,255,255,0.06)" }}
          />
          <StatRow unit={unit} />
        </div>
      </div>

      {/* Grip handle — click to open add popup */}
      <button
        className="flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity rounded p-0.5"
        style={{ color: "#4e5058", background: "transparent" }}
        onClick={(e) => { e.stopPropagation(); onAddClick?.(popupUnit, e); }}
        onMouseEnter={(e) => { e.currentTarget.style.color = "#b5bac1"; }}
        onMouseLeave={(e) => { e.currentTarget.style.color = "#4e5058"; }}
      >
        <GripVertical style={{ width: 14, height: 14 }} />
      </button>
    </div>
  );
}

// ─── Divider with label ───────────────────────────────────────────────────────

function SectionDivider({ label, count }: { label: string; count: number }) {
  return (
    <div className="flex items-center gap-2 px-3 py-2">
      <span
        className="text-[10px] font-black uppercase tracking-widest flex-shrink-0"
        style={{ color: "#4e5058" }}
      >
        {label}
      </span>
      <span
        className="text-[10px] font-bold px-1.5 py-[1px] rounded"
        style={{
          background: "rgba(255,255,255,0.06)",
          color: "#72767d",
          fontFamily: "'JetBrains Mono', monospace",
        }}
      >
        {count}
      </span>
      <div className="flex-1 h-px" style={{ background: "rgba(255,255,255,0.05)" }} />
    </div>
  );
}

// ─── Popup unit type ─────────────────────────────────────────────────────────

interface PopupUnit {
  id: string;
  name: string;
  subtitle: string;
  value: number;
  demand: number;
}

interface PopupState {
  unit: PopupUnit;
  x: number;
  y: number;
}

interface TierConfig {
  label: string;
  units: MasterUnit[];
  badgeChar: string;
  badgeColor: string;
  badgeShadow: string;
  subtitle: string;
}

const TIER_CONFIG: Record<string, TierConfig> = {
  All: { label: "All Tiers", units: ALL_UNITS, badgeChar: "∞", badgeColor: "#5865F2", badgeShadow: "rgba(88,101,242,0.35)", subtitle: "Every tracked unit in the value list" },
  S:   { label: "S Tier",   units: S_UNITS,   badgeChar: "S", badgeColor: "#f59e0b", badgeShadow: "rgba(245,158,11,0.35)", subtitle: "Rarest & most valuable units in the game" },
  A:   { label: "A Tier",   units: A_UNITS,   badgeChar: "A", badgeColor: "#a855f7", badgeShadow: "rgba(168,85,247,0.35)", subtitle: "High-value units with strong demand" },
  B:   { label: "B Tier",   units: B_UNITS,   badgeChar: "B", badgeColor: "#3b82f6", badgeShadow: "rgba(59,130,246,0.35)", subtitle: "Mid-tier units worth holding" },
  C:   { label: "C Tier",   units: C_UNITS,   badgeChar: "C", badgeColor: "#22c55e", badgeShadow: "rgba(34,197,94,0.28)",  subtitle: "Lower-value units, good for bulk trades" },
};

// ─── Grid: status pill badge ──────────────────────────────────────────────────

const GRID_STATUS_CFG: Record<
  UnitStatus,
  { label: string; tip: string; bg: string; border: string; color: string }
> = {
  stable:          { label: "Stable",       tip: "Fair and consistently decent offers. Units that are stable are most likely not to move unless something happens.",  bg: "#3b3924", border: "#6b5f2a", color: "#E6D8A1" },
  unstable:        { label: "Unstable",     tip: "Could rise or drop at any moment, or stabilize.",                                                                  bg: "#1e3040", border: "#3a6480", color: "#6B9EB5" },
  rising:          { label: "Rising",       tip: "Unit is being consistently overpaid.",                                                                             bg: "#153324", border: "#246640", color: "#30A163" },
  dropping:        { label: "Dropping",     tip: "Owners are constantly taking underpays.",                                                                          bg: "#3d0a09", border: "#7a1410", color: "#E60A18" },
  inflated:        { label: "Inflated",     tip: "They are inflated and cost way more than they should be worth.",                                                   bg: "#2d1a0a", border: "#5c3515", color: "#c27a40" },
  deflated:        { label: "Deflated",     tip: "Underpriced, way cheaper than they should be worth.",                                                             bg: "#0e2345", border: "#1e4a8a", color: "#3C81F3" },
  varies:          { label: "Varies",       tip: "Can get fair but can also get lowballs or highballs.",                                                            bg: "#201b42", border: "#3d3480", color: "#9b8de8" },
  maximum:         { label: "Maximum",      tip: "Can get fair at most, but also gets lowballs.",                                                                   bg: "#3d220a", border: "#7a4412", color: "#E66C19" },
  hyped:           { label: "Hyped",        tip: "New unit, or something big changed, skyrocketing value and demand.",                                              bg: "#003d40", border: "#007a80", color: "#01EFFD" },
  gatekept:        { label: "Gatekept",     tip: "Owners are refusing to trade for any reason, waiting for rise or huge overpay.",                                  bg: "#30202e", border: "#603d5a", color: "#AF78A8" },
  "black-marketed":{ label: "Black Market", tip: "People buying units with outside-game currency are heavily impacting this unit.",                                  bg: "#1e2228", border: "#3a4250", color: "#9aa3b2" },
};

function GridStatusBadge({ status }: { status: UnitStatus }) {
  const c = GRID_STATUS_CFG[status];
  const [show, setShow] = useState(false);

  return (
    <div
      className="relative inline-flex"
      onMouseEnter={() => setShow(true)}
      onMouseLeave={() => setShow(false)}
    >
      <div
        className="inline-flex items-center px-2.5 py-[5px] rounded-full cursor-default"
        style={{
          background: c.bg,
          border: `1px solid ${c.border}`,
          color: c.color,
        }}
      >
        <span
          className="text-[11px] font-black tracking-wide"
          style={{ fontFamily: "'Inter', sans-serif" }}
        >
          {c.label}
        </span>
      </div>

      {/* Tooltip */}
      {show && (
        <div
          className="absolute left-0 rounded-xl px-3 py-2 pointer-events-none"
          style={{
            top: "calc(100% + 6px)",
            minWidth: 210,
            maxWidth: 240,
            background: "#111214",
            border: `1px solid ${c.border}`,
            boxShadow: `0 8px 24px rgba(0,0,0,0.6), 0 0 0 1px rgba(0,0,0,0.4)`,
            zIndex: 50,
          }}
        >
          <p
            className="text-[11px] font-bold leading-snug"
            style={{ color: "#F2F3F5", fontFamily: "'Inter', sans-serif" }}
          >
            {c.tip}
          </p>
        </div>
      )}
    </div>
  );
}

// ─── Notice tooltip (?  button) ──────────────────────────────────────────────

function NoticeTooltip({ notice }: { notice: string }) {
  const btnRef = useRef<HTMLSpanElement>(null);
  const [tipPos, setTipPos] = useState<{ x: number; y: number } | null>(null);

  const handleEnter = () => {
    if (!btnRef.current) return;
    const r = btnRef.current.getBoundingClientRect();
    setTipPos({ x: r.left + r.width / 2, y: r.top - 8 });
  };

  return (
    <div className="inline-flex flex-shrink-0" onMouseEnter={handleEnter} onMouseLeave={() => setTipPos(null)}>
      <span
        ref={btnRef}
        className="inline-flex items-center justify-center rounded-full text-[10px] font-black cursor-default select-none"
        style={{
          width: 16, height: 16,
          background: "rgba(255,255,255,0.1)",
          border: "1px solid rgba(255,255,255,0.18)",
          color: "#9ea3ad",
        }}
      >
        ?
      </span>
      {tipPos && (
        <div
          className="rounded-xl px-3 py-2.5 pointer-events-none"
          style={{
            position: "fixed",
            top: tipPos.y,
            left: tipPos.x,
            transform: "translate(-50%, -100%)",
            minWidth: 220,
            maxWidth: 300,
            background: "#111214",
            border: "1px solid rgba(255,255,255,0.14)",
            boxShadow: "0 10px 30px rgba(0,0,0,0.8)",
            zIndex: 9999,
          }}
        >
          <p
            className="text-[11px] font-medium leading-snug"
            style={{ color: "#F2F3F5", fontFamily: "'Inter', sans-serif" }}
          >
            {notice}
          </p>
        </div>
      )}
    </div>
  );
}

// ─── Grid: value display ──────────────────────────────────────────────────────

function GridValueDisplay({ unit }: { unit: GridUnit }) {
  if (unit.value === "owner") {
    return (
      <span
        className="text-[22px] font-black leading-tight"
        style={{
          background: "linear-gradient(90deg, #a78bfa, #f472b6)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          backgroundClip: "text",
          fontFamily: "'Inter', sans-serif",
        }}
      >
        Owner's Choice
      </span>
    );
  }
  if (unit.value === "range") {
    return (
      <span
        className="text-[22px] font-black leading-tight italic"
        style={{ color: "#72767d", fontFamily: "'JetBrains Mono', monospace" }}
      >
        {unit.valueDisplay}
      </span>
    );
  }
  return (
    <span
      className="text-[26px] font-black leading-tight tabular-nums"
      style={{ color: "#F2F3F5", fontFamily: "'JetBrains Mono', monospace" }}
    >
      {(unit.value as number).toLocaleString()}
    </span>
  );
}

// ─── Grid: stat item ──────────────────────────────────────────────────────────

const RARITY_SCALE: { min: number; max: number; label: string }[] = [
  { min: 0,  max: 1,  label: "Common – Easily obtainable" },
  { min: 2,  max: 4,  label: "Uncommon – Somewhat common" },
  { min: 5,  max: 7,  label: "Rare – Less frequently seen" },
  { min: 8,  max: 9,  label: "Very Rare – Hard to come by" },
  { min: 10, max: 10, label: "Pretty Rare – ~5,000 Copies (Aqua rarity)" },
  { min: 11, max: 13, label: "Super Rare – A few thousand copies" },
  { min: 14, max: 15, label: "Ultra Rare – ~1,000 Copies or fewer" },
  { min: 16, max: 17, label: "Extremely Rare – ~500 Copies or fewer" },
  { min: 18, max: 18, label: "Insanely Rare – ~200 Copies or fewer" },
  { min: 19, max: 19, label: "Legendary – ~50 Copies or fewer" },
  { min: 20, max: 20, label: "Ultra Mega Rare – 20 Copies or Less" },
];

const SUPPLY_SCALE: Record<number, string> = {
  1: "Very Low – Barely anyone is selling",
  2: "Low – Few sellers available",
  3: "Medium – Some availability",
  4: "High – Plenty of sellers",
  5: "Very High – Flooded market",
};

const DEMAND_SCALE: Record<number, string> = {
  1: "Very Low – Almost no buyers",
  2: "Low – Few people want it",
  3: "Medium – Moderate interest",
  4: "High – Many buyers competing",
  5: "Very High – Everyone wants it",
};

function getRarityLabel(v: number) {
  const entry = RARITY_SCALE.find((r) => v >= r.min && v <= r.max);
  return entry ? entry.label : "Unknown";
}

function GridStatItem({ label, value }: { label: string; value: number }) {
  const [show, setShow] = useState(false);
  const fmt = (v: number) => (v % 1 === 0 ? String(v) : v.toFixed(1));

  let tipTitle = "";
  let tipBody = "";
  let tipNote = "";

  if (label === "R") {
    tipTitle = `Rarity ${fmt(value)} / 20`;
    tipBody = getRarityLabel(value);
  } else if (label === "S") {
    tipTitle = `Supply ${fmt(value)} / 5`;
    tipBody = SUPPLY_SCALE[Math.round(value)] ?? "Unknown";
  } else if (label === "D") {
    tipTitle = `Demand ${fmt(value)} / 5`;
    tipBody = DEMAND_SCALE[Math.round(value)] ?? "Unknown";
    tipNote = "Note: Demand does not directly drive value.";
  }

  return (
    <span
      className="relative flex items-center gap-1 cursor-default"
      onMouseEnter={() => setShow(true)}
      onMouseLeave={() => setShow(false)}
    >
      <span
        className="text-[16px] font-black uppercase leading-none"
        style={{ color: "#8c9099", fontFamily: "'JetBrains Mono', monospace" }}
      >
        {label}
      </span>
      <span
        className="text-[16px] font-black leading-none"
        style={{ color: "#e3e5e8", fontFamily: "'JetBrains Mono', monospace" }}
      >
        {fmt(value)}
      </span>
      {show && (
        <div
          className="absolute rounded-xl px-3 py-2.5 pointer-events-none"
          style={{
            bottom: "calc(100% + 8px)",
            left: "50%",
            transform: "translateX(-50%)",
            minWidth: 200,
            maxWidth: 240,
            background: "#111214",
            border: "1px solid rgba(255,255,255,0.12)",
            boxShadow: "0 8px 24px rgba(0,0,0,0.7)",
            zIndex: 60,
          }}
        >
          <p className="text-[12px] font-black mb-0.5" style={{ color: "#F2F3F5", fontFamily: "'Inter', sans-serif" }}>
            {tipTitle}
          </p>
          <p className="text-[11px] font-medium leading-snug" style={{ color: "#B5BAC1", fontFamily: "'Inter', sans-serif" }}>
            {tipBody}
          </p>
          {tipNote && (
            <p className="text-[10px] font-medium mt-1.5 leading-snug" style={{ color: "#72767d", fontFamily: "'Inter', sans-serif" }}>
              {tipNote}
            </p>
          )}
        </div>
      )}
    </span>
  );
}

// ─── Grid: unit card ──────────────────────────────────────────────────────────

function TierGridCard({ unit, onAddClick }: { unit: GridUnit; onAddClick?: (u: PopupUnit, e: React.MouseEvent) => void }) {
  const [hovered, setHovered] = useState(false);

  const popupUnit: PopupUnit = {
    id: unit.id,
    name: unit.name,
    subtitle: unit.subtitle,
    value: typeof unit.value === "number" ? unit.value : 0,
    demand: unit.demand,
  };

  const handleDragStart = (e: React.DragEvent) => {
    e.dataTransfer.setData("unit", JSON.stringify(popupUnit));
    e.dataTransfer.effectAllowed = "copy";
  };

  return (
    <div
      draggable
      onDragStart={handleDragStart}
      className="flex flex-col rounded-2xl overflow-hidden cursor-grab active:cursor-grabbing transition-all duration-200"
      style={{
        background: "#2B2D31",
        border: `1px solid ${hovered ? "rgba(255,255,255,0.12)" : "rgba(255,255,255,0.07)"}`,
        boxShadow: hovered
          ? "0 20px 48px rgba(0,0,0,0.55), 0 6px 16px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.07)"
          : "0 8px 24px rgba(0,0,0,0.4), 0 2px 8px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.04)",
        transform: hovered ? "translateY(-3px)" : "translateY(0)",
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* ── Image area ── */}
      <div
        className="relative w-full overflow-hidden"
        style={{ aspectRatio: "1/1" }}
      >
        {/* Background gradient (always visible, serves as fallback) */}
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(160deg, #383a3f 0%, #1E1F22 100%)" }}
        />
        {/* Unit art */}
        {unit.imageUrl ? (
          <img
            src={unit.imageUrl}
            alt={unit.name}
            className="absolute inset-0 w-full h-full"
            style={{ objectFit: "cover", objectPosition: "center 15%" }}
            onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = "none"; }}
          />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center">
            <ImageIcon style={{ width: 32, height: 32, color: "#3a3d44" }} />
          </div>
        )}
        {/* Vignette layers — make art pop while keeping card readable */}
        {/* Left/right edge fade */}
        <div className="absolute inset-0 pointer-events-none" style={{ background: "linear-gradient(to right, rgba(20,21,24,0.45) 0%, transparent 30%, transparent 70%, rgba(20,21,24,0.45) 100%)" }} />
        {/* Strong bottom fade for text readability */}
        <div className="absolute bottom-0 left-0 right-0" style={{ height: "55%", background: "linear-gradient(to bottom, transparent 0%, rgba(18,19,22,0.7) 50%, rgba(15,16,19,0.97) 100%)" }} />
        {/* Top edge fade */}
        <div className="absolute top-0 left-0 right-0 h-10 pointer-events-none" style={{ background: "linear-gradient(to bottom, rgba(15,16,19,0.5) 0%, transparent 100%)" }} />
        {/* Status badge — top left */}
        {unit.status && (
          <div className="absolute top-3 left-3 z-10">
            <GridStatusBadge status={unit.status} />
          </div>
        )}
      </div>

      {/* ── Card body ── */}
      <div className="flex flex-col gap-2 px-4 pt-3.5 pb-4">
        {/* Row 1: Name + notice */}
        <div className="flex items-start gap-2">
          <h3
            className="text-[17px] font-black leading-snug flex-1 min-w-0"
            style={{ color: "#ffffff", fontFamily: "'Inter', sans-serif", textShadow: "0 1px 4px rgba(0,0,0,0.5)" }}
          >
            {unit.name}
          </h3>
          {unit.notice && <div className="mt-0.5"><NoticeTooltip notice={unit.notice} /></div>}
        </div>

        {/* Row 2: Subtitle */}
        <p
          className="text-xs font-semibold leading-none -mt-1"
          style={{ color: "#9ea3ad", fontFamily: "'Inter', sans-serif" }}
        >
          {unit.subtitle}
        </p>

        {/* Row 3: Value — colored left-border accent */}
        <div
          className="mt-1.5 pl-2.5"
          style={{ borderLeft: "3px solid rgba(88,101,242,0.7)" }}
        >
          <GridValueDisplay unit={unit} />
        </div>

        {/* Row 4: Stats bar + plus button */}
        <div
          className="flex items-center justify-between pt-3 mt-1"
          style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}
        >
          <div className="flex items-center gap-2.5">
            <GridStatItem label="R" value={unit.rarity} />
            <span style={{ color: "#2e3035", fontSize: 13, fontWeight: 900 }}>|</span>
            <GridStatItem label="S" value={unit.supply} />
            <span style={{ color: "#2e3035", fontSize: 13, fontWeight: 900 }}>|</span>
            <GridStatItem label="D" value={unit.demand} />
          </div>

          <button
            className="flex-shrink-0 flex items-center justify-center rounded-full text-white transition-all active:scale-90"
            style={{
              width: 30,
              height: 30,
              background: hovered ? "#4752c4" : "#5865F2",
              boxShadow: hovered ? "0 4px 12px rgba(88,101,242,0.5)" : "none",
            }}
            onClick={(e) => { e.stopPropagation(); onAddClick?.(popupUnit, e); }}
          >
            <Plus style={{ width: 14, height: 14 }} />
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Add-to-calculator popup ─────────────────────────────────────────────────

function AddUnitPopup({
  popup,
  onAddGive,
  onAddGet,
  onClose,
}: {
  popup: PopupState;
  onAddGive: (u: PopupUnit) => void;
  onAddGet: (u: PopupUnit) => void;
  onClose: () => void;
}) {
  return (
    <>
      <div className="fixed inset-0" style={{ zIndex: 90 }} onMouseDown={onClose} />
      <div
        className="fixed rounded-xl overflow-hidden"
        style={{
          top: popup.y,
          left: popup.x,
          zIndex: 100,
          minWidth: 188,
          background: "#2B2D31",
          border: "1px solid rgba(255,255,255,0.1)",
          boxShadow: "0 16px 48px rgba(0,0,0,0.72), 0 4px 16px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.05)",
        }}
      >
        {/* Unit label */}
        <div
          className="px-3.5 pt-2.5 pb-2"
          style={{ borderBottom: "1px solid rgba(0,0,0,0.28)" }}
        >
          <p
            className="text-[12px] font-black leading-tight"
            style={{ color: "#F2F3F5", fontFamily: "'Inter', sans-serif" }}
          >
            {popup.unit.name}
          </p>
          <p
            className="text-[10px] mt-0.5"
            style={{ color: "#72767d", fontFamily: "'Inter', sans-serif" }}
          >
            Add to trade calculator
          </p>
        </div>

        {/* Add to Give */}
        <button
          className="w-full flex items-center gap-2.5 px-3.5 py-2.5 text-left transition-colors"
          style={{ color: "#F2F3F5" }}
          onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(88,101,242,0.12)")}
          onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
          onMouseDown={(e) => { e.stopPropagation(); onAddGive(popup.unit); onClose(); }}
        >
          <div
            className="flex-shrink-0 w-4 h-4 rounded-md flex items-center justify-center"
            style={{ background: "rgba(88,101,242,0.2)" }}
          >
            <Plus style={{ width: 9, height: 9, color: "#7984f5" }} />
          </div>
          <span
            className="text-[12.5px] font-bold"
            style={{ fontFamily: "'Inter', sans-serif" }}
          >
            Add to You Give
          </span>
        </button>

        {/* Add to Get */}
        <button
          className="w-full flex items-center gap-2.5 px-3.5 py-2.5 text-left transition-colors"
          style={{ color: "#F2F3F5" }}
          onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(87,242,135,0.08)")}
          onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
          onMouseDown={(e) => { e.stopPropagation(); onAddGet(popup.unit); onClose(); }}
        >
          <div
            className="flex-shrink-0 w-4 h-4 rounded-md flex items-center justify-center"
            style={{ background: "rgba(87,242,135,0.15)" }}
          >
            <Plus style={{ width: 9, height: 9, color: "#57f287" }} />
          </div>
          <span
            className="text-[12.5px] font-bold"
            style={{ fontFamily: "'Inter', sans-serif" }}
          >
            Add to You Get
          </span>
        </button>
      </div>
    </>
  );
}

// ─── Trade modal ─────────────────────────────────────────────────────────────

interface TradeCard {
  id: string;
  name: string;
  subtitle: string;
  value: number;
  demand: number;
  qty: number;
}

const MODAL_GIVE_SEED: TradeCard[] = [
  { id: "tm-ultra-kovegu", name: "Ultra Kovegu", subtitle: "SSJ3 Gogeta", value: 20000, demand: 4, qty: 1 },
];
const MODAL_GET_SEED: TradeCard[] = [
  { id: "tm-death", name: "Death", subtitle: "Ryuk", value: 200000, demand: 1, qty: 1 },
];

const SEARCHABLE_UNITS: { id: string; name: string; subtitle: string; value: number; demand: number }[] = [
  { id: "koku-drip",     name: "Koku (Drip)",   subtitle: "Goku Drip",     value: 34000,  demand: 3 },
  { id: "ultra-kovegu",  name: "Ultra Kovegu",   subtitle: "SSJ3 Gogeta",   value: 20000,  demand: 4 },
  { id: "death",         name: "Death",          subtitle: "Ryuk",          value: 200000, demand: 1 },
  { id: "beardcutter",   name: "Beardcutter",    subtitle: "Goblin Slayer", value: 210000, demand: 1 },
  { id: "slayer-mage",   name: "Slayer Mage",    subtitle: "Frieren",       value: 40000,  demand: 2.5 },
  { id: "galaxy-girl",   name: "Galaxy Girl",    subtitle: "Sasaki Miyo",   value: 350000, demand: 1 },
  { id: "azure-specter", name: "Azure Specter",  subtitle: "Neon Edge",     value: 3200,   demand: 2 },
  { id: "ember-shard",   name: "Ember Shard",    subtitle: "Classic Pure",  value: 900,    demand: 3 },
];

function ActiveCardRow({
  card,
  onQtyChange,
  onRemove,
}: {
  card: TradeCard;
  onQtyChange: (id: string, qty: number) => void;
  onRemove: (id: string) => void;
}) {
  return (
    <div
      className="flex items-center gap-3 px-3 py-2.5 rounded-xl"
      style={{
        background: "#313338",
        border: "1px solid rgba(255,255,255,0.06)",
        boxShadow: "0 2px 8px rgba(0,0,0,0.25)",
      }}
    >
      {/* Thumbnail */}
      <div
        className="flex-shrink-0 rounded-lg flex items-center justify-center"
        style={{
          width: 38,
          height: 38,
          background: "linear-gradient(145deg, #3a3d44, #2b2d31)",
          border: "1px solid rgba(255,255,255,0.06)",
        }}
      >
        <ImageIcon style={{ width: 14, height: 14, color: "#4e5058" }} />
      </div>

      {/* Name + subtitle */}
      <div className="flex-1 min-w-0">
        <p
          className="text-[13px] font-bold leading-tight truncate"
          style={{ color: "#F2F3F5", fontFamily: "'Inter', sans-serif" }}
        >
          {card.name}
        </p>
        <p
          className="text-[10px] truncate leading-tight mt-[1px]"
          style={{ color: "#72767d", fontFamily: "'Inter', sans-serif" }}
        >
          {card.subtitle}
        </p>
      </div>

      {/* Line value */}
      <span
        className="text-sm font-black flex-shrink-0"
        style={{ color: "#B5BAC1", fontFamily: "'JetBrains Mono', monospace" }}
      >
        {(card.value * card.qty).toLocaleString()}
      </span>

      {/* Qty stepper */}
      <div className="flex items-center gap-1.5 flex-shrink-0">
        <button
          onClick={() => card.qty > 1 && onQtyChange(card.id, card.qty - 1)}
          disabled={card.qty <= 1}
          className="w-6 h-6 rounded-md flex items-center justify-center transition-colors disabled:opacity-25 disabled:pointer-events-none"
          style={{ background: "rgba(255,255,255,0.08)", color: "#B5BAC1" }}
          onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(255,255,255,0.14)")}
          onMouseLeave={(e) => (e.currentTarget.style.background = "rgba(255,255,255,0.08)")}
        >
          <Minus style={{ width: 10, height: 10 }} />
        </button>

        <span
          className="w-5 text-center text-xs font-black select-none"
          style={{ color: "#F2F3F5", fontFamily: "'JetBrains Mono', monospace" }}
        >
          {card.qty}
        </span>

        <button
          onClick={() => onQtyChange(card.id, card.qty + 1)}
          className="w-6 h-6 rounded-md flex items-center justify-center transition-colors"
          style={{ background: "rgba(255,255,255,0.08)", color: "#B5BAC1" }}
          onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(255,255,255,0.14)")}
          onMouseLeave={(e) => (e.currentTarget.style.background = "rgba(255,255,255,0.08)")}
        >
          <Plus style={{ width: 10, height: 10 }} />
        </button>
      </div>

      {/* Remove */}
      <button
        onClick={() => onRemove(card.id)}
        className="flex-shrink-0 w-6 h-6 rounded-md flex items-center justify-center transition-colors"
        style={{ background: "transparent", color: "#4e5058" }}
        onMouseEnter={(e) => {
          e.currentTarget.style.background = "rgba(237,66,69,0.14)";
          e.currentTarget.style.color = "#ed4245";
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.background = "transparent";
          e.currentTarget.style.color = "#4e5058";
        }}
      >
        <X style={{ width: 12, height: 12 }} />
      </button>
    </div>
  );
}

function TradeSectionPanel({
  label,
  items,
  onQtyChange,
  onRemove,
  onClear,
  onAdd,
}: {
  label: string;
  items: TradeCard[];
  onQtyChange: (id: string, qty: number) => void;
  onRemove: (id: string) => void;
  onClear: () => void;
  onAdd: (card: TradeCard) => void;
}) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [isDraggingOver, setIsDraggingOver] = useState(false);
  const inputWrapRef = useRef<HTMLDivElement>(null);
  const [dropdownPos, setDropdownPos] = useState<{ top: number; left: number; width: number } | null>(null);
  const blurTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const updateDropdownPos = () => {
    if (inputWrapRef.current) {
      const r = inputWrapRef.current.getBoundingClientRect();
      setDropdownPos({ top: r.bottom + 4, left: r.left, width: r.width });
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "copy";
    setIsDraggingOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    if (!e.currentTarget.contains(e.relatedTarget as Node)) {
      setIsDraggingOver(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(false);
    const raw = e.dataTransfer.getData("unit");
    if (!raw) return;
    try {
      const u: PopupUnit = JSON.parse(raw);
      const existing = items.find((c) => c.id === u.id);
      if (existing) {
        onQtyChange(existing.id, existing.qty + 1);
      } else {
        onAdd({ id: u.id, name: u.name, subtitle: u.subtitle, value: u.value, demand: u.demand, qty: 1 });
      }
    } catch { /* malformed payload — ignore */ }
  };

  const total = items.reduce((s, c) => s + c.value * c.qty, 0);

  const results = SEARCHABLE_UNITS.filter(
    (u) =>
      query === "" ||
      u.name.toLowerCase().includes(query.toLowerCase()) ||
      u.subtitle.toLowerCase().includes(query.toLowerCase())
  ).slice(0, 5);

  const handleAdd = (u: typeof SEARCHABLE_UNITS[0]) => {
    const existing = items.find((i) => i.id === u.id);
    if (existing) {
      onQtyChange(existing.id, existing.qty + 1);
    } else {
      onAdd({ id: u.id, name: u.name, subtitle: u.subtitle, value: u.value, demand: u.demand, qty: 1 });
    }
    setQuery("");
    setOpen(false);
  };

  return (
    <div className="px-3 py-3">
      {/* Section header */}
      <div className="flex items-baseline justify-between mb-2.5">
        <div>
          <p
            className="text-[10px] font-black uppercase tracking-widest"
            style={{ color: "#4e5058", fontFamily: "'Inter', sans-serif" }}
          >
            {label}
          </p>
          {items.length > 0 && (
            <p
              className="text-base font-black leading-tight mt-0.5"
              style={{ color: "#F2F3F5", fontFamily: "'JetBrains Mono', monospace" }}
            >
              {total.toLocaleString()}
            </p>
          )}
        </div>
        {items.length > 0 && (
          <button
            className="text-xs font-bold transition-colors"
            style={{ color: "#72767d" }}
            onClick={onClear}
            onMouseEnter={(e) => (e.currentTarget.style.color = "#b5bac1")}
            onMouseLeave={(e) => (e.currentTarget.style.color = "#72767d")}
          >
            Clear
          </button>
        )}
      </div>

      {/* Search input */}
      <div className="relative mb-2.5" ref={inputWrapRef}>
        <div
          className="flex items-center gap-2 px-3 py-2 rounded-xl"
          style={{
            background: "#1E1F22",
            border: `1px solid ${open ? "rgba(88,101,242,0.45)" : "rgba(255,255,255,0.07)"}`,
            boxShadow: open ? "0 0 0 3px rgba(88,101,242,0.12)" : "none",
            transition: "border-color 0.15s, box-shadow 0.15s",
          }}
        >
          <Search style={{ width: 13, height: 13, color: "#4e5058", flexShrink: 0 }} />
          <input
            type="text"
            value={query}
            placeholder="Type anime or in-game name..."
            className="flex-1 bg-transparent outline-none text-[12.5px]"
            style={{
              color: "#B5BAC1",
              fontFamily: "'Inter', sans-serif",
              caretColor: "#5865F2",
            }}
            onChange={(e) => { setQuery(e.target.value); updateDropdownPos(); setOpen(true); }}
            onFocus={() => { if (blurTimer.current) clearTimeout(blurTimer.current); updateDropdownPos(); setOpen(true); }}
            onBlur={() => { blurTimer.current = setTimeout(() => setOpen(false), 160); }}
          />
          {query.length > 0 && (
            <button
              className="flex-shrink-0"
              style={{ color: "#4e5058" }}
              onMouseDown={(e) => { e.preventDefault(); setQuery(""); }}
            >
              <X style={{ width: 12, height: 12 }} />
            </button>
          )}
        </div>

        {/* Autocomplete dropdown — fixed so it escapes any overflow:hidden ancestor */}
        {open && results.length > 0 && dropdownPos && (
          <div
            className="rounded-xl overflow-hidden"
            style={{
              position: "fixed",
              top: dropdownPos.top,
              left: dropdownPos.left,
              width: dropdownPos.width,
              background: "#2B2D31",
              border: "1px solid rgba(255,255,255,0.1)",
              boxShadow:
                "0 20px 56px rgba(0,0,0,0.72), 0 8px 24px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.05)",
              zIndex: 200,
            }}
            onMouseDown={(e) => e.preventDefault()}
          >
            <p
              className="px-3 pt-2.5 pb-1.5 text-[9px] font-black uppercase tracking-widest"
              style={{ color: "#4e5058", fontFamily: "'Inter', sans-serif" }}
            >
              Quick Add
            </p>
            {results.map((u, i) => (
              <button
                key={u.id}
                onClick={() => handleAdd(u)}
                className="w-full flex items-center gap-3 px-3 py-2.5 transition-colors text-left"
                style={{
                  borderTop: i === 0 ? "none" : "1px solid rgba(0,0,0,0.2)",
                }}
                onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(88,101,242,0.12)")}
                onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
              >
                {/* Mini thumb */}
                <div
                  className="flex-shrink-0 rounded-lg flex items-center justify-center"
                  style={{
                    width: 34,
                    height: 34,
                    background: "linear-gradient(145deg, #3a3d44, #2b2d31)",
                    border: "1px solid rgba(255,255,255,0.07)",
                  }}
                >
                  <ImageIcon style={{ width: 11, height: 11, color: "#4e5058" }} />
                </div>

                {/* Name + subtitle */}
                <div className="flex-1 min-w-0">
                  <p
                    className="text-[12.5px] font-bold leading-tight truncate"
                    style={{ color: "#F2F3F5", fontFamily: "'Inter', sans-serif" }}
                  >
                    {u.name}
                  </p>
                  <p
                    className="text-[10px] leading-tight mt-[1px] truncate"
                    style={{ color: "#72767d", fontFamily: "'Inter', sans-serif" }}
                  >
                    {u.subtitle}
                  </p>
                </div>

                {/* Value */}
                <span
                  className="text-[12px] font-black flex-shrink-0"
                  style={{ color: "#B5BAC1", fontFamily: "'JetBrains Mono', monospace" }}
                >
                  {u.value.toLocaleString()}
                </span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Drop zone — card list */}
      <div
        className="rounded-xl transition-all duration-150"
        style={{
          padding: isDraggingOver ? "6px" : "0px",
          background: isDraggingOver ? "rgba(88,101,242,0.08)" : "transparent",
          border: isDraggingOver ? "2px solid #5865F2" : "2px solid transparent",
          boxShadow: isDraggingOver ? "0 0 0 3px rgba(88,101,242,0.12), inset 0 0 12px rgba(88,101,242,0.06)" : "none",
        }}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        {items.length === 0 ? (
          <div
            className="min-h-[56px] rounded-lg flex items-center justify-center gap-2"
            style={{
              border: isDraggingOver ? "none" : "2px dashed rgba(255,255,255,0.06)",
            }}
          >
            {isDraggingOver ? (
              <p
                className="text-[11px] font-black"
                style={{ color: "#7984f5", fontFamily: "'Inter', sans-serif" }}
              >
                Drop to add
              </p>
            ) : (
              <p
                className="text-[11px] font-bold"
                style={{ color: "#3e4147", fontFamily: "'Inter', sans-serif" }}
              >
                Search or drop units here
              </p>
            )}
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            {items.map((card) => (
              <ActiveCardRow
                key={card.id}
                card={card}
                onQtyChange={onQtyChange}
                onRemove={onRemove}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function TradeAnalyzerPanel({
  giveItems,
  getItems,
  onChangeQty,
  onRemoveCard,
  onClear,
  onAdd,
}: {
  giveItems: TradeCard[];
  getItems: TradeCard[];
  onChangeQty: (col: "give" | "get", id: string, qty: number) => void;
  onRemoveCard: (col: "give" | "get", id: string) => void;
  onClear: (col: "give" | "get") => void;
  onAdd: (col: "give" | "get", card: TradeCard) => void;
}) {
  const [copied, setCopied] = useState(false);

  const fmtK = (n: number) =>
    n >= 1000 ? `${Math.round(n / 1000)}k` : `${n}`;

  const handleShare = () => {
    const giveParts = giveItems.map((c) => `${c.qty}x ${c.name} (${fmtK(c.value * c.qty)})`).join(", ");
    const getParts  = getItems.map((c) => `${c.qty}x ${c.name} (${fmtK(c.value * c.qty)})`).join(", ");
    const netDiffVal = getItems.reduce((s, c) => s + c.value * c.qty, 0)
                     - giveItems.reduce((s, c) => s + c.value * c.qty, 0);
    const netStr = netDiffVal === 0 ? "EVEN" : netDiffVal > 0 ? `+${fmtK(netDiffVal)}` : `−${fmtK(Math.abs(netDiffVal))}`;
    const giveStr = giveParts || "nothing";
    const getStr  = getParts  || "nothing";
    const text = `[GIVE] ${giveStr} ➔ [GET] ${getStr} | NET: ${netStr}`;
    const tryWrite = async () => {
      try {
        await navigator.clipboard.writeText(text);
      } catch {
        // Fallback for sandboxed/permission-blocked contexts
        const ta = document.createElement("textarea");
        ta.value = text;
        ta.style.cssText = "position:fixed;top:-9999px;left:-9999px;opacity:0";
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        document.execCommand("copy");
        document.body.removeChild(ta);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    };
    tryWrite();
  };

  const giveTotal = giveItems.reduce((s, c) => s + c.value * c.qty, 0);
  const getTotal  = getItems.reduce((s, c) => s + c.value * c.qty, 0);
  const netDiff   = getTotal - giveTotal;

  const fmtDiff = (n: number) =>
    n === 0 ? "Even" : n > 0 ? `+${n.toLocaleString()}` : `−${Math.abs(n).toLocaleString()}`;

  const avgDemand = (items: TradeCard[]) =>
    items.length === 0 ? "—" : (items.reduce((s, c) => s + c.demand, 0) / items.length).toFixed(1);

  return (
    <div
      className="flex-shrink-0 flex flex-col h-screen select-none"
      style={{
        width: 400,
        minWidth: 400,
        background: "#1E1F22",
        borderLeft: "1px solid rgba(0,0,0,0.32)",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      {/* ── Panel header ── */}
      <div
        className="flex-shrink-0 flex items-center gap-3 px-4 py-3.5"
        style={{ borderBottom: "1px solid rgba(0,0,0,0.28)" }}
      >
        <div
          className="w-7 h-7 flex-shrink-0 rounded-lg flex items-center justify-center"
          style={{ background: "rgba(88,101,242,0.18)", border: "1px solid rgba(88,101,242,0.28)" }}
        >
          <Calculator style={{ width: 14, height: 14, color: "#7984f5" }} />
        </div>
        <span
          className="text-[14px] font-black flex-1"
          style={{ color: "#F2F3F5" }}
        >
          Trade Analyzer
        </span>

        {/* Reset All button */}
        <button
          onClick={() => { onClear("give"); onClear("get"); }}
          title="Reset calculator"
          className="flex-shrink-0 w-7 h-7 flex items-center justify-center rounded-lg transition-colors"
          style={{ color: "#4e5058", background: "transparent" }}
          onMouseEnter={(e) => { e.currentTarget.style.background = "rgba(255,255,255,0.07)"; e.currentTarget.style.color = "#b5bac1"; }}
          onMouseLeave={(e) => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "#4e5058"; }}
        >
          <RotateCcw style={{ width: 13, height: 13 }} />
        </button>

        {/* Share Trade button */}
        <button
          onClick={handleShare}
          className="flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11.5px] font-black transition-all active:scale-95"
          style={{
            background: copied ? "#23a559" : "#5865F2",
            color: "#fff",
            fontFamily: "'Inter', sans-serif",
            boxShadow: copied
              ? "0 2px 10px rgba(35,165,89,0.4)"
              : "0 2px 10px rgba(88,101,242,0.35)",
            transition: "background 0.25s, box-shadow 0.25s",
          }}
        >
          {copied
            ? <Check style={{ width: 12, height: 12 }} />
            : <Share2 style={{ width: 12, height: 12 }} />
          }
          {copied ? "Copied!" : "Share"}
        </button>
      </div>

      {/* ── Summary box ── */}
      <div
        className="flex-shrink-0 mx-3 mt-3 rounded-xl px-4 py-3.5"
        style={{
          background: "#202225",
          border: "1px solid rgba(0,0,0,0.3)",
          boxShadow: "0 4px 16px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.03)",
        }}
      >
        {/* Net value diff */}
        <div className="mb-3">
          <p
            className="text-[9px] font-black uppercase tracking-widest mb-1"
            style={{ color: "#4e5058" }}
          >
            Net Value Diff
          </p>
          <p
            className="text-2xl font-black leading-none"
            style={{ color: "#F2F3F5", fontFamily: "'JetBrains Mono', monospace" }}
          >
            {fmtDiff(netDiff)}
          </p>
        </div>


        {/* Divider */}
        <div style={{ height: 1, background: "rgba(255,255,255,0.04)", marginBottom: 12 }} />

        {/* Demand shift */}
        <div>
          <p
            className="text-[9px] font-black uppercase tracking-widest mb-1"
            style={{ color: "#4e5058" }}
          >
            Demand Shift
          </p>
          <p
            className="text-lg font-black leading-none flex items-center gap-2"
            style={{ color: "#F2F3F5", fontFamily: "'JetBrains Mono', monospace" }}
          >
            <span>{avgDemand(giveItems)}</span>
            <span style={{ color: "#4e5058", fontSize: 14 }}>➔</span>
            <span>{avgDemand(getItems)}</span>
          </p>
        </div>
      </div>

      {/* ── Scrollable trade sections ── */}
      <div className="flex-1 overflow-y-auto py-1" style={{ scrollbarWidth: "none" }}>
        <TradeSectionPanel
          label="You Give"
          items={giveItems}
          onQtyChange={(id, qty) => onChangeQty("give", id, qty)}
          onRemove={(id) => onRemoveCard("give", id)}
          onClear={() => onClear("give")}
          onAdd={(card) => onAdd("give", card)}
        />

        {/* Section divider */}
        <div
          className="mx-3 my-1"
          style={{ height: 1, background: "rgba(255,255,255,0.04)" }}
        />

        <TradeSectionPanel
          label="You Get"
          items={getItems}
          onQtyChange={(id, qty) => onChangeQty("get", id, qty)}
          onRemove={(id) => onRemoveCard("get", id)}
          onClear={() => onClear("get")}
          onAdd={(card) => onAdd("get", card)}
        />
      </div>

      {/* ── Footer disclaimer ── */}
      <footer
        className="flex-shrink-0 flex items-start gap-2 px-4 py-3"
        style={{ borderTop: "1px solid rgba(0,0,0,0.28)" }}
      >
        <TriangleAlert style={{ width: 11, height: 11, color: "#4e5058", flexShrink: 0, marginTop: 1 }} />
        <p
          className="text-[10px] leading-relaxed"
          style={{ color: "#4e5058" }}
        >
          Values are lagging indicators. Factor in demand, rarity, and knowledge before accepting.
        </p>
      </footer>
    </div>
  );
}

// ─── Grid helpers ────────────────────────────────────────────────────────────

function UnitGrid({ units, onAddUnit }: { units: MasterUnit[]; onAddUnit: (u: PopupUnit, e: React.MouseEvent) => void }) {
  return (
    <div className="grid gap-4" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))" }}>
      {units.map((unit) => (
        <TierGridCard key={unit.id} unit={unit} onAddClick={onAddUnit} />
      ))}
    </div>
  );
}

function STierSubHeader({ label, valueRange, count }: { label: string; valueRange: string; count: number }) {
  return (
    <div className="flex items-center gap-3 mb-4 mt-2">
      <div>
        <span className="text-[13px] font-black" style={{ color: "#F2F3F5", fontFamily: "'Inter', sans-serif" }}>{label}</span>
        <span className="text-[11px] font-bold ml-2" style={{ color: "#4e5058" }}>{valueRange}</span>
      </div>
      <div className="flex-1 h-px" style={{ background: "rgba(255,255,255,0.06)" }} />
      <span className="text-[10px] font-bold px-2 py-0.5 rounded" style={{ background: "rgba(255,255,255,0.06)", color: "#72767d" }}>{count}</span>
    </div>
  );
}

function STierSections({ units, onAddUnit }: { units: MasterUnit[]; onAddUnit: (u: PopupUnit, e: React.MouseEvent) => void }) {
  const top = units.filter(u => u.value === "owner" || u.value === "range" || (typeof u.value === "number" && u.value >= 100000));
  const mid = units.filter(u => typeof u.value === "number" && u.value >= 20000 && u.value < 100000);
  const low = units.filter(u => typeof u.value === "number" && u.value >= 10000 && u.value < 20000);

  return (
    <div className="flex flex-col gap-10">
      {top.length > 0 && (
        <div>
          <STierSubHeader label="Top S Tier" valueRange="100,000 – O/C" count={top.length} />
          <UnitGrid units={top} onAddUnit={onAddUnit} />
        </div>
      )}
      {mid.length > 0 && (
        <div>
          <STierSubHeader label="Mid S Tier" valueRange="20,000 – 99,999" count={mid.length} />
          <UnitGrid units={mid} onAddUnit={onAddUnit} />
        </div>
      )}
      {low.length > 0 && (
        <div>
          <STierSubHeader label="Low S Tier" valueRange="10,000 – 19,999" count={low.length} />
          <UnitGrid units={low} onAddUnit={onAddUnit} />
        </div>
      )}
    </div>
  );
}

// ─── Main canvas ──────────────────────────────────────────────────────────────

function MainCanvas({
  activeTierFilter,
  onAddUnit,
}: {
  activeTierFilter: string;
  onAddUnit: (u: PopupUnit, e: React.MouseEvent) => void;
}) {
  const tier = TIER_CONFIG[activeTierFilter] ?? TIER_CONFIG["S"];

  return (
    <div
      className="flex-1 flex flex-col overflow-y-auto"
      style={{ background: "#313338", scrollbarWidth: "none" }}
    >
      {/* ── Canvas top nav bar ── */}
      <div
        className="flex-shrink-0 flex items-center justify-between px-8 py-4"
        style={{ borderBottom: "1px solid rgba(0,0,0,0.22)" }}
      >
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full" style={{ background: tier.badgeColor }} />
          <span
            className="text-[11px] font-black uppercase tracking-widest"
            style={{ color: "#4e5058" }}
          >
            Tier List
          </span>
        </div>
        <span
          className="text-[11px] font-mono font-bold px-2.5 py-1 rounded-lg"
          style={{
            background: "rgba(255,255,255,0.04)",
            color: "#4e5058",
            border: "1px solid rgba(255,255,255,0.05)",
          }}
        >
          {tier.units.length} units
        </span>
      </div>

      {/* ── Page content ── */}
      <div className="px-8 py-8">
        {/* Tier section header */}
        <div className="flex items-center gap-4 mb-8">
          <div
            className="flex-shrink-0 flex items-center justify-center rounded-xl text-white font-black transition-colors duration-300"
            style={{
              width: 52,
              height: 52,
              background: tier.badgeColor,
              fontSize: tier.badgeChar.length > 1 ? 20 : 26,
              fontFamily: "'Inter', sans-serif",
              boxShadow: `0 4px 16px ${tier.badgeShadow}`,
            }}
          >
            {tier.badgeChar}
          </div>

          <div>
            <h1
              className="text-2xl font-black leading-tight transition-colors duration-300"
              style={{ color: "#F2F3F5", fontFamily: "'Inter', sans-serif" }}
            >
              {tier.label}
            </h1>
            <p
              className="text-sm mt-0.5"
              style={{ color: "#72767d", fontFamily: "'Inter', sans-serif" }}
            >
              {tier.subtitle}
            </p>
          </div>

          <div
            className="flex-1 ml-2 hidden sm:block"
            style={{ height: 1, background: "rgba(255,255,255,0.05)" }}
          />
        </div>

        {tier.units.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 gap-4">
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center" style={{ background: "rgba(255,255,255,0.04)" }}>
              <Search style={{ width: 24, height: 24, color: "#4e5058" }} />
            </div>
            <p className="text-sm font-bold" style={{ color: "#4e5058" }}>No units in this tier yet</p>
          </div>
        ) : activeTierFilter === "S" ? (
          <STierSections units={tier.units} onAddUnit={onAddUnit} />
        ) : (
          <UnitGrid units={tier.units} onAddUnit={onAddUnit} />
        )}
      </div>
    </div>
  );
}

// ─── Unit Roster sidebar ──────────────────────────────────────────────────────

function UnitRoster({
  activeTierFilter,
  setActiveTierFilter,
  onAddUnit,
}: {
  activeTierFilter: FilterKey;
  setActiveTierFilter: (f: FilterKey) => void;
  onAddUnit: (u: PopupUnit, e: React.MouseEvent) => void;
}) {
  const [search, setSearch] = useState("");
  const [sortOption, setSortOption] = useState<"value-desc" | "demand-desc" | "alpha-asc">("value-desc");
  const chipRowRef = useRef<HTMLDivElement>(null);

  const filtered = ROSTER
    .filter((u) => {
      const q = search.toLowerCase();
      const matchSearch =
        u.name.toLowerCase().includes(q) || u.subtitle.toLowerCase().includes(q);
      const matchFilter =
        activeTierFilter === "All" ? true : getTier(u.value) === activeTierFilter;
      return matchSearch && matchFilter;
    })
    .sort((a, b) => {
      if (sortOption === "value-desc") return sortVal(b) - sortVal(a);
      if (sortOption === "demand-desc") return b.demand - a.demand;
      return a.name.localeCompare(b.name);
    });

  return (
    <div
      className="flex flex-col h-full select-none"
      style={{
        width: 300,
        minWidth: 300,
        background: "#1E1F22",
        borderRight: "1px solid rgba(0,0,0,0.32)",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      {/* ── Panel header ── */}
      <div
        className="flex-shrink-0 px-4 pt-5 pb-4"
        style={{ borderBottom: "1px solid rgba(0,0,0,0.28)" }}
      >
        {/* Title row */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div
              className="squircle w-7 h-7 flex items-center justify-center flex-shrink-0"
              style={{ background: "linear-gradient(135deg, #5865F2, #7984f5)" }}
            >
              <Layers style={{ width: 14, height: 14, color: "#fff" }} />
            </div>
            <div>
              <p
                className="text-[13px] font-black leading-tight"
                style={{ color: "#F2F3F5" }}
              >
                Unit Roster
              </p>
              <p
                className="text-[10px] leading-none mt-[1px]"
                style={{ color: "#72767d" }}
              >
                {ROSTER.length} units total
              </p>
            </div>
          </div>
          <div className="relative flex-shrink-0">
            <select
              value={sortOption}
              onChange={(e) => setSortOption(e.target.value as typeof sortOption)}
              className="appearance-none text-[11px] font-bold rounded-lg cursor-pointer outline-none pr-6 pl-2.5 py-1.5"
              style={{
                background: "rgba(88,101,242,0.15)",
                color: "#7984f5",
                border: "none",
                fontFamily: "'Inter', sans-serif",
              }}
            >
              <option value="value-desc">Value ↓</option>
              <option value="demand-desc">Demand ↓</option>
              <option value="alpha-asc">A → Z</option>
            </select>
            <ChevronDown
              style={{ width: 10, height: 10, color: "#7984f5", position: "absolute", right: 6, top: "50%", transform: "translateY(-50%)", pointerEvents: "none" }}
            />
          </div>
        </div>

        {/* Search bar */}
        <div className="relative">
          <Search
            className="absolute top-1/2 -translate-y-1/2 pointer-events-none"
            style={{ left: 12, width: 14, height: 14, color: "#72767d" }}
          />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search anime or in-game name..."
            className="w-full text-sm outline-none transition-all"
            style={{
              background: "#1E1F22",
              border: "1.5px solid transparent",
              borderRadius: 10,
              paddingLeft: 36,
              paddingRight: 12,
              paddingTop: 9,
              paddingBottom: 9,
              color: "#F2F3F5",
              fontFamily: "'Inter', sans-serif",
              fontSize: 12.5,
            }}
            onFocus={(e) => (e.currentTarget.style.borderColor = "rgba(88,101,242,0.6)")}
            onBlur={(e) => (e.currentTarget.style.borderColor = "transparent")}
          />
        </div>
      </div>

      {/* ── Filter chips (horizontal scroll) ── */}
      <div
        ref={chipRowRef}
        className="flex-shrink-0 flex items-center gap-1.5 px-4 py-3 overflow-x-auto"
        style={{ scrollbarWidth: "none" }}
      >
        {FILTERS.map((f) => (
          <button
            key={f}
            onClick={() => setActiveTierFilter(f)}
            className="flex-shrink-0 px-3 py-[5px] rounded-full text-[11px] font-bold transition-all"
            style={
              activeTierFilter === f
                ? {
                    background: "#5865F2",
                    color: "#fff",
                    boxShadow: "0 2px 8px rgba(88,101,242,0.4)",
                  }
                : {
                    background: "rgba(255,255,255,0.05)",
                    color: "#72767d",
                  }
            }
            onMouseEnter={(e) => {
              if (activeTierFilter !== f) e.currentTarget.style.background = "rgba(78,80,88,0.35)";
            }}
            onMouseLeave={(e) => {
              if (activeTierFilter !== f) e.currentTarget.style.background = "rgba(255,255,255,0.05)";
            }}
          >
            {f}
          </button>
        ))}
      </div>

      {/* ── Unit list ── */}
      <div
        className="flex-1 overflow-y-auto"
        style={{ scrollbarWidth: "none" }}
      >
        {filtered.length === 0 ? (
          <div
            className="flex flex-col items-center justify-center h-full gap-3 py-16 px-6 text-center"
          >
            <div
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{ background: "rgba(255,255,255,0.04)" }}
            >
              <Search style={{ width: 20, height: 20, color: "#4e5058" }} />
            </div>
            <p className="text-sm font-bold" style={{ color: "#4e5058" }}>
              No units match
            </p>
            <p className="text-xs" style={{ color: "#3e4147" }}>
              Try a different name or filter
            </p>
          </div>
        ) : (
          <>
            <SectionDivider label="Roster" count={filtered.length} />
            <div className="px-2 pb-4">
              {filtered.map((unit, i) => (
                <div key={unit.id}>
                  <UnitCard unit={unit} onAddClick={onAddUnit} />
                  {i < filtered.length - 1 && (
                    <div
                      className="mx-3"
                      style={{ height: 1, background: "rgba(255,255,255,0.03)" }}
                    />
                  )}
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* ── Footer hint ── */}
      <div
        className="flex-shrink-0 flex items-center justify-center gap-1.5 px-4 py-3"
        style={{ borderTop: "1px solid rgba(0,0,0,0.28)" }}
      >
        <GripVertical style={{ width: 12, height: 12, color: "#3e4147" }} />
        <p className="text-[10px]" style={{ color: "#3e4147" }}>
          Click grip to add unit to calculator
        </p>
      </div>
    </div>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [globalYouGive, setGlobalYouGive] = useState<TradeCard[]>(MODAL_GIVE_SEED);
  const [globalYouGet,  setGlobalYouGet]  = useState<TradeCard[]>(MODAL_GET_SEED);
  const [activeTierFilter, setActiveTierFilter] = useState<FilterKey>("S");
  const [addPopup, setAddPopup] = useState<PopupState | null>(null);

  const addToColumn = (col: "give" | "get", unit: PopupUnit) => {
    const setter = col === "give" ? setGlobalYouGive : setGlobalYouGet;
    setter((prev) => {
      const existing = prev.find((c) => c.id === unit.id);
      if (existing) return prev.map((c) => c.id === unit.id ? { ...c, qty: c.qty + 1 } : c);
      return [...prev, { id: unit.id, name: unit.name, subtitle: unit.subtitle, value: unit.value, demand: unit.demand, qty: 1 }];
    });
  };

  const handleChangeQty = (col: "give" | "get", id: string, qty: number) => {
    const setter = col === "give" ? setGlobalYouGive : setGlobalYouGet;
    setter((prev) => prev.map((c) => (c.id === id ? { ...c, qty } : c)));
  };

  const handleRemoveCard = (col: "give" | "get", id: string) => {
    const setter = col === "give" ? setGlobalYouGive : setGlobalYouGet;
    setter((prev) => prev.filter((c) => c.id !== id));
  };

  const handleClear = (col: "give" | "get") => {
    if (col === "give") setGlobalYouGive([]);
    else setGlobalYouGet([]);
  };

  const handleAddCard = (col: "give" | "get", card: TradeCard) => {
    const setter = col === "give" ? setGlobalYouGive : setGlobalYouGet;
    setter((prev) => {
      const existing = prev.find((c) => c.id === card.id);
      if (existing) return prev.map((c) => c.id === card.id ? { ...c, qty: c.qty + 1 } : c);
      return [...prev, card];
    });
  };

  const openPopup = (unit: PopupUnit, e: React.MouseEvent) => {
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const x = Math.min(rect.right + 8, window.innerWidth - 200);
    const y = Math.min(rect.top, window.innerHeight - 120);
    setAddPopup({ unit, x, y });
  };

  return (
    <div
      className="flex h-screen overflow-hidden"
      style={{
        background: "#313338",
        fontFamily: "'Inter', sans-serif",
        color: "#F2F3F5",
      }}
    >
      {addPopup && (
        <AddUnitPopup
          popup={addPopup}
          onAddGive={(u) => addToColumn("give", u)}
          onAddGet={(u) => addToColumn("get", u)}
          onClose={() => setAddPopup(null)}
        />
      )}

      <UnitRoster
        activeTierFilter={activeTierFilter}
        setActiveTierFilter={setActiveTierFilter}
        onAddUnit={openPopup}
      />
      <MainCanvas
        activeTierFilter={activeTierFilter}
        onAddUnit={openPopup}
      />
      <TradeAnalyzerPanel
        giveItems={globalYouGive}
        getItems={globalYouGet}
        onChangeQty={handleChangeQty}
        onRemoveCard={handleRemoveCard}
        onClear={handleClear}
        onAdd={handleAddCard}
      />
    </div>
  );
}
